//---------------------------------------------------------------------------
#ifndef MI2463CommonData_unitH
#define MI2463CommonData_unitH

#include <mitools.h>
#include "variable.h"
#include "density.h"
#include "mm.h"
#include "prover.h"
//---------------------------------------------------------------------------
class TMI2463CommonData:public TMICommonData
{
public:
   __fastcall ~TMI2463CommonData();
   __fastcall TMI2463CommonData();
   char* Products;
   int ProductCount;
   HINSTANCE hProver;
   HINSTANCE hDensity;
   HINSTANCE hMM;
   HINSTANCE hMITools;
   fStudent Student095;
   fStudent Student099;
   fViewMM ViewMM;
   fViewProverProperties ViewProver;
   fViewFD ViewFD;
   fManageMM ManageMM;
   fManageFD ManageFD;
   fManage ManageProver;
   fCalculateDensity CalculateDensity;
};
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
#endif

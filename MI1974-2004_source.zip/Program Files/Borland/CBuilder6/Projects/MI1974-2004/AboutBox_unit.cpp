//---------------------------------------------------------------------
#include <vcl.h>
#include "Pch.H"
#pragma hdrstop


//#include <mapi.hpp>
#include "AboutBox_unit.h"
//---------------------------------------------------------------------
#pragma resource "*.dfm"
TAboutBox *AboutBox;
//---------------------------------------------------------------------
__fastcall TAboutBox::TAboutBox(TComponent* AOwner)
	: TForm(AOwner)
{
}
//---------------------------------------------------------------------
void __fastcall TAboutBox::Label1Click(TObject *Sender)
{
  ShellExecute(Handle, "open","mailto:corvinalive@list.ru?subject=��������� �� 1974-2004",
     0, 0, SW_SHOW);
}
//---------------------------------------------------------------------------
/*void __fastcall TAboutBox::Label3Click(TObject *Sender)
{
  ShellExecute(Handle, "open","http://www.intramail.ru/~corvin/",
     0, 0, SW_SHOW);
} */
//---------------------------------------------------------------------------


//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "tpr.h"
#include <OleCtrls.hpp>
#include <ActnList.hpp>
#include <StdActns.hpp>

#include "TPRDLLInterface.h"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TButton *Button1;
	TButton *Button2;
	TButton *Button3;
	TButton *Button4;
   TButton *Button5;
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall Button4Click(TObject *Sender);
   void __fastcall Button5Click(TObject *Sender);

private:	// User declarations
public:		// User declarations
   TTPRDLLInterface* Inter;
	__fastcall TForm1(TComponent* Owner);
	__fastcall ~TForm1();
	HINSTANCE hinstLib;
	TTPR MM;
	IStorage* Root;
   bool __fastcall AppHelp(Word Command, int Data, bool &CallHelp);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif

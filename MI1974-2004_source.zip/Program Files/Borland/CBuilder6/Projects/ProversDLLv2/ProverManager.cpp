//---------------------------------------------------------------------------

#include <windows.h>
#include "shfolder.hpp"
#include "shlwapi.h"
#pragma hdrstop
typedef void (*Manage)(void* Owner);

//---------------------------------------------------------------------------
#pragma argsused
WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
   char FN[260];
   SHGetFolderPath(0,CSIDL_PROGRAM_FILES,0,0,FN);
   PathAppend(FN,"Amber Inc\\Shared Files\\ProverDLL.dll");
    HINSTANCE hinstLib = LoadLibrary(FN);
    if (hinstLib != NULL)
      {
      Manage f;
      f=(Manage) GetProcAddress(hinstLib,"_Manage");
      if(f==NULL)
         MessageBox(0,"������","�� ���� ����� ����� ������� Manage",MB_ICONSTOP);
      else
         f(0);
      }
    else
      MessageBox(0,"Error load DLL","Error",MB_ICONSTOP);
   return 0;
}
//---------------------------------------------------------------------------

